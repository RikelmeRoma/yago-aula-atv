package com.example.usedev

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
