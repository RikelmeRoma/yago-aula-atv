//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation


func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
}
